/**
 * pipeline-ui.js - 工作流 UI 模块
 *
 * 支持单文件模式和批量模式：
 * - 单文件模式：上传 1 个 PDF，处理完直接下载
 * - 批量模式：上传多个 PDF，处理完打包 ZIP 下载
 *
 * 复用 pipeline.js 核心中间层和 batch-pipeline.js 批量引擎。
 */

import { runPipeline } from './pipeline.js'
import { runBatchPipeline, BATCH_MAX_FILE_SIZE, BATCH_MAX_COUNT } from './batch-pipeline.js'
import { saveTemplate, loadTemplate, loadTemplates, deleteTemplate } from './storage.js'
import {
  formatSize,
  showStatus,
  showProcessing,
  showSuccess,
  showError,
  clearStatus,
  downloadBlob,
  checkFileSize,
  trackEvent,
  showUploadFileInfo,
  resetUploadZone,
  highlightUploadZone,
  cleanupResources,
} from '../utils.js'

// PDF.js lazy import (avoid duplicating the worker setup from main.js)
let pdfjsLib = null
async function getPdfjs() {
  if (!pdfjsLib) {
    pdfjsLib = await import('pdfjs-dist')
  }
  return pdfjsLib
}

export function initPipeline() {
  // === DOM Elements ===
  const uploadZone = document.getElementById('pipeline-upload')
  const fileInput = document.getElementById('pipeline-file')
  const pipelineCard = document.getElementById('pipeline-card')
  const runBtn = document.getElementById('pipeline-run-btn')
  const closeBtn = document.getElementById('pipeline-close')
  const statusEl = document.getElementById('pipeline-status')
  const downloadSection = document.getElementById('pipeline-download')
  const downloadBtn = document.getElementById('pipeline-download-btn')
  const wmCheckbox = document.querySelector('.pipeline-step-check[data-step="watermark"]')
  const wmOptions = document.getElementById('pipeline-wm-options')
  const mergeCheckbox = document.querySelector('.pipeline-step-check[data-step="merge"]')
  const mergeOptions = document.getElementById('pipeline-merge-options')
  const splitCheckbox = document.querySelector('.pipeline-step-check[data-step="split"]')
  const splitOptions = document.getElementById('pipeline-split-options')

  // Batch mode elements
  const batchSwitch = document.getElementById('pipeline-batch-switch')
  const batchHint = document.getElementById('pipeline-batch-hint')
  const batchUploadZone = document.getElementById('pipeline-batch-upload')
  const batchFileInput = document.getElementById('pipeline-batch-file')
  const batchFileList = document.getElementById('pipeline-batch-filelist')
  const batchCount = document.getElementById('pipeline-batch-count')
  const batchClearBtn = document.getElementById('pipeline-batch-clear')
  const batchList = document.getElementById('pipeline-batch-list')
  const batchResult = document.getElementById('pipeline-batch-result')
  const batchSummary = document.getElementById('pipeline-batch-summary')
  const batchDownloadBtn = document.getElementById('pipeline-batch-download-btn')
  const singleInfo = document.getElementById('pipeline-single-info')

  let uploadedFile = null
  let resultBytes = null
  let pdfPageCount = 0

  // Batch mode state
  let isBatchMode = false
  let batchFiles = []
  let batchZipBlob = null

  // Merge step state
  let mergeExtraFiles = []

  // ---- Template definitions ----
  const TEMPLATES = {
    invoice: {
      steps: ['merge', 'compress', 'watermark'],
      watermark: { text: '已审核', position: 'tile', fontSize: 50, opacity: 20 },
    },
    report: {
      steps: ['compress', 'metadata'],
      watermark: null,
      metadata: { author: '公司名称' },
    },
    contract: {
      steps: ['compress', 'watermark'],
      watermark: { text: '机密', position: 'center', fontSize: 50, opacity: 20 },
    },
  }

  // Custom templates loaded from IndexedDB
  let customTemplates = []

  // ---- Template management elements (injected dynamically) ----
  const templateSelect = document.getElementById('pipeline-template-select')
  const templateLoadBtn = document.getElementById('pipeline-template-load-btn')
  const templateManageBtn = document.getElementById('pipeline-template-manage-btn')

  // ---- Template section containers (injected dynamically) ----
  const templatesGrid = document.getElementById('pipeline-templates-grid')
  const customSection = document.getElementById('pipeline-custom-templates-section')
  const saveTemplateBtn = document.getElementById('pipeline-save-template-btn')

  // ---- Apply template on click ----
  function applyTemplate(templateId) {
    // Check custom templates first
    const customTpl = customTemplates.find(t => t.name === templateId)
    if (customTpl) {
      applyTemplateData(customTpl.data)
      highlightTemplate(templateId)
      return
    }

    // Check built-in templates
    const tpl = TEMPLATES[templateId]
    if (!tpl) return

    applyTemplateData(tpl)
    highlightTemplate(templateId)
  }

  function applyTemplateData(tpl) {
    // Reset all checkboxes first
    document.querySelectorAll('.pipeline-step-check').forEach(cb => {
      cb.checked = tpl.steps.includes(cb.dataset.step)
    })

    // Fill watermark parameters
    if (tpl.watermark) {
      const wmText = document.getElementById('pipeline-wm-text')
      const wmFontSize = document.getElementById('pipeline-wm-fontsize')
      const wmOpacity = document.getElementById('pipeline-wm-opacity')
      const wmPositionRadio = document.querySelector(
        `input[name="pipeline-wm-position"][value="${tpl.watermark.position}"]`,
      )

      if (wmText) wmText.value = tpl.watermark.text
      if (wmFontSize) {
        wmFontSize.value = tpl.watermark.fontSize
        document.getElementById('pipeline-wm-fontsize-val').textContent = tpl.watermark.fontSize
      }
      if (wmOpacity) {
        wmOpacity.value = tpl.watermark.opacity
        document.getElementById('pipeline-wm-opacity-val').textContent = tpl.watermark.opacity + '%'
      }
      if (wmPositionRadio) wmPositionRadio.checked = true
    }

    // Show watermark options if watermark step is selected
    updateWmOptionsVisibility()
    // Show metadata options if metadata step is selected
    updateMdOptionsVisibility()
    // Show merge options if merge step is selected
    updateMergeOptionsVisibility()
    // Show split options if split step is selected
    updateSplitOptionsVisibility()

    // Fill split range if provided
    if (tpl.split && tpl.split.range) {
      const splitRangeInput = document.getElementById('pipeline-split-range')
      if (splitRangeInput) splitRangeInput.value = tpl.split.range
    }

    // Fill metadata fields if provided
    if (tpl.metadata) {
      const mdTitle = document.getElementById('pipeline-md-title')
      const mdAuthor = document.getElementById('pipeline-md-author')
      const mdSubject = document.getElementById('pipeline-md-subject')
      const mdKeywords = document.getElementById('pipeline-md-keywords')
      if (mdTitle) mdTitle.value = tpl.metadata.title || ''
      if (mdAuthor) mdAuthor.value = tpl.metadata.author || ''
      if (mdSubject) mdSubject.value = tpl.metadata.subject || ''
      if (mdKeywords) mdKeywords.value = tpl.metadata.keywords || ''
    }
  }

  function highlightTemplate(templateId) {
    document.querySelectorAll('.pipeline-template-card').forEach(card => {
      card.classList.remove('template-active')
    })
    const clickedCard = document.querySelector(`[data-template="${templateId}"]`)
    if (clickedCard) clickedCard.classList.add('template-active')
  }

  // Bind template card clicks (built-in)
  document.querySelectorAll('.pipeline-template-card[data-template]').forEach(card => {
    card.addEventListener('click', () => applyTemplate(card.dataset.template))
  })

  // ---- Load custom templates ----
  async function loadCustomTemplates() {
    try {
      customTemplates = await loadTemplates()
      renderCustomTemplates()
    } catch (err) {
      console.warn('[Pipeline] 加载自定义模板失败:', err)
    }
  }

  // ---- Render custom templates ----
  function renderCustomTemplates() {
    if (!customSection || !templatesGrid) return

    // Clear previous custom template cards
    const existing = templatesGrid.querySelectorAll('.custom-template-card')
    existing.forEach(el => el.remove())

    if (customTemplates.length === 0) {
      customSection.style.display = 'none'
      return
    }

    customSection.style.display = ''

    for (const tpl of customTemplates) {
      const card = document.createElement('button')
      card.className = 'pipeline-template-card custom-template-card'
      card.dataset.template = tpl.name
      card.dataset.custom = 'true'
      const stepCount = tpl.data.steps.length
      const wmLabel = tpl.data.watermark ? ` + 水印` : ''
      card.innerHTML = `
        <span class="pipeline-template-icon">⭐</span>
        <span class="pipeline-template-name" title="${escapeHtml(tpl.name)}">${escapeHtml(tpl.name)}</span>
        <span class="pipeline-template-desc">${stepCount} 个步骤${wmLabel}</span>
        <span class="custom-template-delete" data-name="${escapeHtml(tpl.name)}" title="删除">🗑️</span>
      `
      card.addEventListener('click', (e) => {
        // Don't apply template if delete button was clicked
        if (e.target.classList.contains('custom-template-delete')) return
        applyTemplate(tpl.name)
      })
      templatesGrid.appendChild(card)
    }

    // Bind delete buttons
    templatesGrid.querySelectorAll('.custom-template-delete').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation()
        const name = btn.dataset.name
        if (!confirm(`确定删除模板「${name}」？`)) return
        try {
          await deleteTemplate(name)
          customTemplates = customTemplates.filter(t => t.name !== name)
          renderCustomTemplates()
        } catch (err) {
          console.error('[Pipeline] 删除模板失败:', err)
        }
      })
    })
  }

  // ---- Post-pipeline save template prompt ----
  /**
   * After pipeline completion, prompt user to save current steps as a template.
   * Non-blocking: uses a lightweight inline prompt instead of modal.
   */
  function promptSaveTemplate(steps) {
    if (!steps || steps.length === 0) return

    const saveAfterRun = document.createElement('div')
    saveAfterRun.style.cssText = 'margin-top:12px;padding:12px;background:#f0f9ff;border:1px solid #90caf9;border-radius:8px;display:flex;align-items:center;gap:8px;font-size:0.875rem;'
    saveAfterRun.innerHTML = `
      <span style="flex:1;">💾 是否将当前步骤配置保存为模板，方便下次使用？</span>
      <button class="btn btn-sm btn-primary" id="save-after-run-yes">保存</button>
      <button class="btn btn-sm btn-outline" id="save-after-run-no">跳过</button>
    `

    // Insert after status element
    if (statusEl && statusEl.parentNode) {
      statusEl.parentNode.insertBefore(saveAfterRun, statusEl.nextSibling)
    }

    const yesBtn = document.getElementById('save-after-run-yes')
    const noBtn = document.getElementById('save-after-run-no')

    if (yesBtn) {
      yesBtn.addEventListener('click', () => {
        saveAfterRun.remove()
        handleSaveTemplate()
      })
    }
    if (noBtn) {
      noBtn.addEventListener('click', () => {
        saveAfterRun.remove()
      })
    }

    // Auto-dismiss after 15 seconds
    setTimeout(() => {
      if (saveAfterRun.parentNode) saveAfterRun.remove()
    }, 15000)
  }

  // ---- Save as template ----
  async function handleSaveTemplate() {
    const checks = document.querySelectorAll('.pipeline-step-check:checked')
    if (checks.length === 0) {
      showStatus(statusEl, '⚠️ 请至少选择一个处理步骤后再保存', 'warning')
      return
    }

    const name = prompt('请输入模板名称：')
    if (!name || !name.trim()) return

    const trimmedName = name.trim()

    // Check for duplicate name
    if (TEMPLATES[trimmedName] || customTemplates.find(t => t.name === trimmedName)) {
      if (!confirm(`模板「${trimmedName}」已存在，是否覆盖？`)) return
    }

    const steps = []
    for (const cb of checks) {
      const stepType = cb.dataset.step
      if (stepType === 'compress') {
        steps.push({ type: 'compress' })
      } else if (stepType === 'watermark') {
        const text = document.getElementById('pipeline-wm-text').value.trim()
        const fontSize = parseInt(wmFontSizeRange.value, 10)
        const opacity = parseInt(wmOpacityRange.value, 10) / 100
        const position = document.querySelector('input[name="pipeline-wm-position"]:checked')?.value || 'center'
        steps.push({
          type: 'watermark',
          mode: 'text',
          text: text || 'DRAFT',
          fontSize,
          opacity,
          position,
        })
      } else if (stepType === 'stripJS') {
        steps.push({ type: 'stripJS' })
      } else if (stepType === 'metadata') {
        const title = document.getElementById('pipeline-md-title').value.trim()
        const author = document.getElementById('pipeline-md-author').value.trim()
        const subject = document.getElementById('pipeline-md-subject').value.trim()
        const keywords = document.getElementById('pipeline-md-keywords').value.trim()
        steps.push({
          type: 'metadata',
          title, author, subject, keywords,
        })
      } else if (stepType === 'merge') {
        // merge files are runtime-only, save as step marker
        steps.push({ type: 'merge' })
      } else if (stepType === 'split') {
        const range = document.getElementById('pipeline-split-range').value.trim()
        steps.push({ type: 'split', range: range || '1' })
      }
    }

    const stepTypes = steps.map(s => s.type)
    const wmStep = steps.find(s => s.type === 'watermark')
    const watermarkData = wmStep
      ? {
          text: wmStep.text,
          position: wmStep.position,
          fontSize: wmStep.fontSize,
          opacity: wmStep.opacity * 100,
        }
      : null
    const mdStep = steps.find(s => s.type === 'metadata')
    const metadataData = mdStep
      ? { title: mdStep.title, author: mdStep.author, subject: mdStep.subject, keywords: mdStep.keywords }
      : null
    const mergeStep = steps.find(s => s.type === 'merge')
    const mergeData = mergeStep ? true : null
    const splitStep = steps.find(s => s.type === 'split')
    const splitData = splitStep ? { range: splitStep.range } : null

    const data = { steps: stepTypes, watermark: watermarkData, metadata: metadataData, merge: mergeData, split: splitData }

    try {
      await saveTemplate(trimmedName, data)
      customTemplates = await loadTemplates()
      renderCustomTemplates()
      refreshTemplateSelector()
      showStatus(statusEl, `✅ 模板「${trimmedName}」已保存`, 'success')
    } catch (err) {
      console.error('[Pipeline] 保存模板失败:', err)
      showStatus(statusEl, '❌ 保存模板失败：' + err.message, 'error')
    }
  }

  if (saveTemplateBtn) {
    saveTemplateBtn.addEventListener('click', handleSaveTemplate)
  }

  // =========================================================================
  // Template Selector Dropdown
  // =========================================================================

  /**
   * Populate the template selector dropdown with saved templates
   */
  function populateTemplateSelector() {
    if (!templateSelect) return

    // Clear existing options (keep the default option)
    templateSelect.innerHTML = '<option value="">-- 选择模板 --</option>'

    if (customTemplates.length === 0) {
      templateSelectorSection.style.display = 'none'
      return
    }

    templateSelectorSection.style.display = ''

    for (const tpl of customTemplates) {
      const option = document.createElement('option')
      option.value = tpl.name
      const stepCount = tpl.data.steps ? tpl.data.steps.length : 0
      option.textContent = `${tpl.name} (${stepCount} 个步骤)`
      templateSelect.appendChild(option)
    }
  }

  // Update dropdown when templates change
  function refreshTemplateSelector() {
    populateTemplateSelector()
    if (templateLoadBtn) templateLoadBtn.disabled = true
  }

  // Template select change - enable/disable load button
  if (templateSelect) {
    templateSelect.addEventListener('change', () => {
      if (templateLoadBtn) {
        templateLoadBtn.disabled = !templateSelect.value
      }
    })
  }

  // Template load button - apply selected template
  if (templateLoadBtn) {
    templateLoadBtn.addEventListener('click', () => {
      const selectedName = templateSelect.value
      if (!selectedName) return
      applyTemplate(selectedName)
      // Update dropdown selection visual
      templateSelect.value = selectedName
    })
  }

  // =========================================================================
  // Template Management Modal
  // =========================================================================

  /**
   * Open template management modal
   */
  function openTemplateManageModal() {
    if (typeof window.openModal === 'function') {
      window.openModal('template-manage')
    }
    renderTemplateManageList()
  }

  /**
   * Render the template list in the management modal
   */
  function renderTemplateManageList() {
    const listEl = document.getElementById('template-manage-list')
    if (!listEl) return

    if (customTemplates.length === 0) {
      listEl.innerHTML = '<p style="color:#999;text-align:center;padding:2rem;">暂无已保存的模板</p>'
      return
    }

    listEl.innerHTML = customTemplates.map(tpl => {
      const stepCount = tpl.data.steps ? tpl.data.steps.length : 0
      const stepsDesc = (tpl.data.steps || []).join(' → ')
      const wmText = tpl.data.watermark ? ` | 水印: ${escapeHtml(tpl.data.watermark.text || '')}` : ''
      const splitRange = tpl.data.split && tpl.data.split.range ? ` | 页码: ${escapeHtml(tpl.data.split.range)}` : ''
      const timeStr = tpl.createdAt ? new Date(tpl.createdAt).toLocaleString('zh-CN') : ''
      return `
        <div class="template-manage-item" style="display:flex;align-items:center;gap:12px;padding:12px;border:1px solid #eee;border-radius:8px;margin-bottom:8px;">
          <div style="flex:1;min-width:0;">
            <div style="font-weight:600;margin-bottom:4px;">${escapeHtml(tpl.name)}</div>
            <div style="font-size:0.8rem;color:#666;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${escapeHtml(stepsDesc + wmText + splitRange)}">
              ${stepCount} 个步骤: ${escapeHtml(stepsDesc)}${wmText}${splitRange}
            </div>
            ${timeStr ? `<div style="font-size:0.7rem;color:#999;margin-top:2px;">保存于 ${timeStr}</div>` : ''}
          </div>
          <div style="display:flex;gap:4px;flex-shrink:0;">
            <button class="btn btn-sm btn-outline template-manage-load-btn" data-name="${escapeHtml(tpl.name)}" title="加载此模板">加载</button>
            <button class="btn btn-sm btn-danger template-manage-delete-btn" data-name="${escapeHtml(tpl.name)}" title="删除此模板">🗑️</button>
          </div>
        </div>
      `
    }).join('')

    // Bind load buttons
    listEl.querySelectorAll('.template-manage-load-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        applyTemplate(btn.dataset.name)
        if (typeof window.closeModal === 'function') {
          window.closeModal('template-manage')
        }
      })
    })

    // Bind delete buttons
    listEl.querySelectorAll('.template-manage-delete-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const name = btn.dataset.name
        if (!confirm(`确定删除模板「${name}」？`)) return
        try {
          await deleteTemplate(name)
          customTemplates = await loadTemplates()
          renderCustomTemplates()
          refreshTemplateSelector()
          renderTemplateManageList()
        } catch (err) {
          console.error('[Pipeline] 删除模板失败:', err)
        }
      })
    })
  }

  // Template manage button
  if (templateManageBtn) {
    templateManageBtn.addEventListener('click', openTemplateManageModal)
  }

  // Load custom templates on init
  loadCustomTemplates().then(() => {
    refreshTemplateSelector()
  })

  // ---- Toggle watermark options ----
  function updateWmOptionsVisibility() {
    wmOptions.style.display = wmCheckbox.checked ? 'block' : 'none'
  }
  wmCheckbox.addEventListener('change', updateWmOptionsVisibility)

  // ---- Toggle merge options ----
  function updateMergeOptionsVisibility() {
    mergeOptions.style.display = mergeCheckbox.checked ? 'block' : 'none'
  }
  mergeCheckbox.addEventListener('change', updateMergeOptionsVisibility)

  // ---- Toggle split options ----
  function updateSplitOptionsVisibility() {
    splitOptions.style.display = splitCheckbox.checked ? 'block' : 'none'
  }
  splitCheckbox.addEventListener('change', updateSplitOptionsVisibility)

  // =========================================================================
  // Merge File Upload
  // =========================================================================
  const mergeUploadZone = document.getElementById('pipeline-merge-upload-zone')
  const mergeFileInput = document.getElementById('pipeline-merge-files')
  const mergeFileList = document.getElementById('pipeline-merge-file-list')

  if (mergeUploadZone && mergeFileInput) {
    mergeUploadZone.addEventListener('click', () => mergeFileInput.click())

    mergeUploadZone.addEventListener('dragover', e => {
      e.preventDefault()
      mergeUploadZone.style.borderColor = '#4a90d9'
    })
    mergeUploadZone.addEventListener('dragleave', () => {
      mergeUploadZone.style.borderColor = '#ccc'
    })
    mergeUploadZone.addEventListener('drop', e => {
      e.preventDefault()
      mergeUploadZone.style.borderColor = '#ccc'
      if (e.dataTransfer.files.length > 0) {
        addMergeExtraFiles(e.dataTransfer.files)
      }
    })

    mergeFileInput.addEventListener('change', () => {
      if (mergeFileInput.files.length > 0) {
        addMergeExtraFiles(mergeFileInput.files)
        mergeFileInput.value = ''
      }
    })
  }

  function addMergeExtraFiles(files) {
    for (const f of files) {
      if (f.type === 'application/pdf' || f.name.endsWith('.pdf')) {
        mergeExtraFiles.push(f)
      }
    }
    renderMergeFileList()
  }

  function renderMergeFileList() {
    if (!mergeFileList) return
    if (mergeExtraFiles.length === 0) {
      mergeFileList.innerHTML = ''
      return
    }
    mergeFileList.innerHTML = mergeExtraFiles.map((f, i) => `
      <div style="display:flex;align-items:center;gap:8px;padding:4px 0;font-size:0.875rem;">
        <span>📄</span>
        <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapeHtml(f.name)}">${escapeHtml(f.name)}</span>
        <span style="color:#999;font-size:0.75rem;">${formatSize(f.size)}</span>
        <button class="merge-remove-btn" data-index="${i}" style="background:none;border:none;cursor:pointer;color:#e74c3c;font-size:1rem;line-height:1;">✕</button>
      </div>
    `).join('')

    // Bind remove buttons
    mergeFileList.querySelectorAll('.merge-remove-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.index, 10)
        mergeExtraFiles.splice(idx, 1)
        renderMergeFileList()
      })
    })
  }

  // ---- Toggle metadata options ----
  function updateMdOptionsVisibility() {
    const mdOptions = document.getElementById('pipeline-md-options')
    const mdCheckbox = document.querySelector('.pipeline-step-check[data-step="metadata"]')
    if (mdOptions && mdCheckbox) {
      mdOptions.style.display = mdCheckbox.checked ? 'block' : 'none'
    }
  }

  // ---- Range value display ----
  const wmFontSizeRange = document.getElementById('pipeline-wm-fontsize')
  const wmFontSizeVal = document.getElementById('pipeline-wm-fontsize-val')
  const wmOpacityRange = document.getElementById('pipeline-wm-opacity')
  const wmOpacityVal = document.getElementById('pipeline-wm-opacity-val')

  wmFontSizeRange.addEventListener('input', () => {
    wmFontSizeVal.textContent = wmFontSizeRange.value
  })
  wmOpacityRange.addEventListener('input', () => {
    wmOpacityVal.textContent = wmOpacityRange.value + '%'
  })

  // =========================================================================
  // Batch Mode Toggle
  // =========================================================================
  if (batchSwitch) {
    batchSwitch.addEventListener('change', () => {
      isBatchMode = batchSwitch.checked
      batchHint.style.display = isBatchMode ? 'inline' : 'none'
      uploadZone.style.display = isBatchMode ? 'none' : ''
      fileInput.style.display = isBatchMode ? 'none' : ''
      batchUploadZone.style.display = isBatchMode ? '' : 'none'
      batchFileInput.style.display = isBatchMode ? '' : 'none'

      // Reset state
      uploadedFile = null
      resultBytes = null
      batchFiles = []
      batchZipBlob = null
      mergeExtraFiles = []
      pipelineCard.style.display = 'none'
      downloadSection.style.display = 'none'
      batchResult.style.display = 'none'
      batchFileList.style.display = 'none'
      singleInfo.style.display = 'none'
      clearStatus(statusEl)
    })
  }

  // =========================================================================
  // Single File Upload
  // =========================================================================
  if (uploadZone && fileInput) {
    uploadZone.addEventListener('click', () => fileInput.click())
    fileInput.addEventListener('change', () => {
      if (fileInput.files.length > 0) handleFile(fileInput.files[0])
    })

    // Drag & drop
    uploadZone.addEventListener('dragover', e => {
      e.preventDefault()
      uploadZone.classList.add('dragover')
    })
    uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('dragover'))
    uploadZone.addEventListener('drop', e => {
      e.preventDefault()
      uploadZone.classList.remove('dragover')
      if (e.dataTransfer.files.length > 0) {
        fileInput.files = e.dataTransfer.files
        handleFile(e.dataTransfer.files[0])
      }
    })
  }

  async function handleFile(file) {
    if (file.type !== 'application/pdf') {
      clearStatus(statusEl)
      showError(statusEl, '⚠️ 请选择 PDF 文件')
      return
    }
    if (!checkFileSize(file, statusEl)) return

    uploadedFile = file
    resultBytes = null
    mergeExtraFiles = []
    if (mergeFileList) mergeFileList.innerHTML = ''
    downloadSection.style.display = 'none'
    clearStatus(statusEl)

    // Show file info in upload zone
    showUploadFileInfo(uploadZone, file)

    // Show file info in detail section
    document.getElementById('pipeline-filename').textContent = file.name
    document.getElementById('pipeline-filesize').textContent = formatSize(file.size)
    singleInfo.style.display = 'block'
    pipelineCard.style.display = 'block'
    runBtn.disabled = false

    // Get page count via PDF.js
    try {
      const lib = await getPdfjs()
      const arrayBuffer = await file.arrayBuffer()
      const pdfDoc = await lib.getDocument({ data: new Uint8Array(arrayBuffer) }).promise
      pdfPageCount = pdfDoc.numPages
      document.getElementById('pipeline-pages').textContent = pdfPageCount + ' 页'
      // Update split range placeholder with actual page count
      const splitRangeInput = document.getElementById('pipeline-split-range')
      if (splitRangeInput && pdfPageCount > 0) {
        splitRangeInput.placeholder = `例如: 1-${Math.min(3, pdfPageCount)},${pdfPageCount}`
      }
      trackEvent('file_uploaded', { feature: 'pipeline', size: file.size, pages: pdfPageCount })
    } catch (err) {
      console.warn('[Pipeline] 获取页数失败:', err)
      document.getElementById('pipeline-pages').textContent = '-'
    }
  }

  // =========================================================================
  // Batch File Upload
  // =========================================================================
  if (batchUploadZone && batchFileInput) {
    batchUploadZone.addEventListener('click', () => batchFileInput.click())
    batchFileInput.addEventListener('change', () => {
      if (batchFileInput.files.length > 0) handleBatchFiles(Array.from(batchFileInput.files))
    })

    // Drag & drop
    batchUploadZone.addEventListener('dragover', e => {
      e.preventDefault()
      batchUploadZone.classList.add('dragover')
    })
    batchUploadZone.addEventListener('dragleave', () => batchUploadZone.classList.remove('dragover'))
    batchUploadZone.addEventListener('drop', e => {
      e.preventDefault()
      batchUploadZone.classList.remove('dragover')
      if (e.dataTransfer.files.length > 0) {
        handleBatchFiles(Array.from(e.dataTransfer.files))
      }
    })
  }

  function handleBatchFiles(files) {
    // Validate count
    if (files.length > BATCH_MAX_COUNT) {
      showError(statusEl, `⚠️ 文件数量过多（${files.length} 个），最多支持 ${BATCH_MAX_COUNT} 个`)
      return
    }

    // Clear previous results
    clearStatus(statusEl)
    downloadSection.style.display = 'none'
    batchResult.style.display = 'none'
    batchZipBlob = null

    // Add to batch list (deduplicate by name)
    const existingNames = new Set(batchFiles.map(f => f.name))
    let added = 0
    let skipped = 0

    for (const file of files) {
      if (file.type !== 'application/pdf') {
        skipped++
        continue
      }
      if (file.size > BATCH_MAX_FILE_SIZE) {
        skipped++
        continue
      }
      if (existingNames.has(file.name)) {
        skipped++
        continue
      }

      if (batchFiles.length >= BATCH_MAX_COUNT) {
        break
      }

      batchFiles.push(file)
      existingNames.add(file.name)
      added++
    }

    // Update UI
    renderBatchFileList()

    // Highlight batch upload zone
    if (batchFiles.length > 0) {
      highlightUploadZone(batchUploadZone)
    } else {
      resetUploadZone(batchUploadZone)
    }

    // Show info
    if (added > 0) {
      clearStatus(statusEl)
    }
    if (skipped > 0) {
      showStatus(statusEl, `ℹ️ 已添加 ${added} 个文件，跳过 ${skipped} 个（非 PDF 或超限或重复）`, 'info')
    }

    // Enable run button if we have files and steps
    updateBatchRunState()
  }

  function renderBatchFileList() {
    if (batchFiles.length === 0) {
      batchFileList.style.display = 'none'
      pipelineCard.style.display = 'none'
      return
    }

    batchFileList.style.display = 'block'
    pipelineCard.style.display = 'block'
    batchCount.textContent = `${batchFiles.length} 个文件（总 ${formatSize(batchFiles.reduce((s, f) => s + f.size, 0))}）`

    batchList.innerHTML = batchFiles.map(f => `
      <div class="batch-file-item" data-name="${escapeHtml(f.name)}">
        <span class="batch-file-name" title="${escapeHtml(f.name)}">${escapeHtml(f.name)}</span>
        <span class="batch-file-size">${formatSize(f.size)}</span>
        <span class="batch-file-status"></span>
      </div>
    `).join('')
  }

  function updateBatchRunState() {
    const checks = document.querySelectorAll('.pipeline-step-check:checked')
    runBtn.disabled = batchFiles.length === 0 || checks.length === 0
  }

  if (batchClearBtn) {
    batchClearBtn.addEventListener('click', () => {
      batchFiles = []
      batchZipBlob = null
      mergeExtraFiles = []
      if (mergeFileList) mergeFileList.innerHTML = ''
      batchFileInput.value = ''
      renderBatchFileList()
      resetUploadZone(batchUploadZone)
      clearStatus(statusEl)
      downloadSection.style.display = 'none'
      batchResult.style.display = 'none'
      runBtn.disabled = true
    })
  }

  // =========================================================================
  // Build steps from UI
  // =========================================================================
  function buildSteps() {
    const steps = []
    const checks = document.querySelectorAll('.pipeline-step-check:checked')
    for (const cb of checks) {
      const stepType = cb.dataset.step
      if (stepType === 'compress') {
        steps.push({ type: 'compress' })
      } else if (stepType === 'watermark') {
        const text = document.getElementById('pipeline-wm-text').value.trim()
        if (!text) {
          showError(statusEl, '⚠️ 请输入水印文字')
          return null
        }
        const fontSize = parseInt(wmFontSizeRange.value, 10)
        const opacity = parseInt(wmOpacityRange.value, 10) / 100
        const position = document.querySelector('input[name="pipeline-wm-position"]:checked').value

        steps.push({
          type: 'watermark',
          mode: 'text',
          text,
          fontSize,
          opacity,
          position,
        })
      } else if (stepType === 'stripJS') {
        steps.push({ type: 'stripJS' })
      } else if (stepType === 'metadata') {
        const title = document.getElementById('pipeline-md-title').value.trim()
        const author = document.getElementById('pipeline-md-author').value.trim()
        const subject = document.getElementById('pipeline-md-subject').value.trim()
        const keywords = document.getElementById('pipeline-md-keywords').value.trim()

        if (!title && !author && !subject && !keywords) {
          showError(statusEl, '⚠️ 请至少填写一个元数据字段')
          return null
        }

        steps.push({
          type: 'metadata',
          title,
          author,
          subject,
          keywords,
        })
      } else if (stepType === 'merge') {
        if (mergeExtraFiles.length === 0) {
          showError(statusEl, '⚠️ 合并步骤需要上传至少一个额外的 PDF 文件')
          return null
        }
        steps.push({
          type: 'merge',
          extraFiles: mergeExtraFiles,
        })
      } else if (stepType === 'split') {
        const range = document.getElementById('pipeline-split-range').value.trim()
        if (!range) {
          showError(statusEl, '⚠️ 请输入页码范围（如 1-3,5,8-10）')
          return null
        }
        steps.push({
          type: 'split',
          range,
          totalPages: pdfPageCount,
        })
      }
    }
    return steps
  }

  // =========================================================================
  // Run Pipeline (single or batch)
  // =========================================================================
  if (runBtn) {
    runBtn.addEventListener('click', async () => {
      const steps = buildSteps()
      if (!steps) return
      if (steps.length === 0) {
        showError(statusEl, '⚠️ 请至少选择一个处理步骤')
        return
      }

      if (isBatchMode) {
        await runBatch(steps)
      } else {
        await runSingle(steps)
      }
    })
  }

  // =========================================================================
  // Single File Processing
  // =========================================================================
  async function runSingle(steps) {
    if (!uploadedFile) return

    runBtn.disabled = true
    downloadSection.style.display = 'none'
    resultBytes = null

    const startTime = performance.now()
    const originalSize = uploadedFile.size

    try {
      showProcessing(statusEl, `正在处理 ${steps.length} 个步骤...`)

      resultBytes = await runPipeline(
        await uploadedFile.arrayBuffer(),
        steps,
        (completed, total, name) => {
          const progressText = statusEl.querySelector('.progress-text')
          if (progressText) {
            const stepNames = {
              compress: '压缩', watermark: '水印', stripJS: '剥离 JS',
              metadata: '元数据', merge: '合并', split: '拆分',
            }
            const label = stepNames[name] || name
            progressText.textContent = `✅ ${label} 完成 (${completed}/${total})`
          }
        },
      )

      const duration = performance.now() - startTime

      showSuccess(statusEl, `✅ ${steps.length} 个步骤处理完成，耗时 ${(duration / 1000).toFixed(1)} 秒`)

      downloadSection.style.display = 'block'

      // Post-pipeline: prompt to save as template
      promptSaveTemplate(steps)

      trackEvent('pipeline_completed', {
        steps: steps.length,
        originalSize,
        processedSize: resultBytes.length,
        duration,
      })
    } catch (err) {
      console.error('[Pipeline] 执行失败:', err)
      showError(statusEl, '❌ 处理失败：' + err.message)
    } finally {
      runBtn.disabled = false
    }
  }

  // =========================================================================
  // Batch Processing
  // =========================================================================
  async function runBatch(steps) {
    if (batchFiles.length === 0) return

    runBtn.disabled = true
    downloadSection.style.display = 'none'
    batchResult.style.display = 'none'
    batchZipBlob = null

    const startTime = performance.now()
    const totalFiles = batchFiles.length
    const totalOriginalSize = batchFiles.reduce((s, f) => s + f.size, 0)

    try {
      showProcessing(statusEl, `正在批量处理 ${totalFiles} 个文件...`)

      const result = await runBatchPipeline(batchFiles, steps, {
        onFileProgress: (fileIndex, total, fileName) => {
          const progressText = statusEl.querySelector('.progress-text')
          if (progressText) {
            progressText.textContent = `📄 处理文件 (${fileIndex + 1}/${total}): ${fileName}`
          }
          // Update file list status
          updateFileStatus(fileIndex, 'processing')
        },
        onStepProgress: (fileIndex, stepCompleted, totalSteps, stepName) => {
          const stepNames = {
            compress: '压缩', watermark: '水印', stripJS: '剥离 JS',
            metadata: '元数据', merge: '合并', split: '拆分',
          }
          const label = stepNames[stepName] || stepName
          const progressText = statusEl.querySelector('.progress-text')
          if (progressText) {
            progressText.textContent = `📄 ${fileIndex + 1}/${totalFiles} - ${label} (${stepCompleted}/${totalSteps})`
          }
        },
      })

      const duration = performance.now() - startTime
      batchZipBlob = result.zipBlob

      // Update file list statuses
      result.successFiles.forEach(sf => {
        const idx = batchFiles.findIndex(f => f.name === sf.name)
        if (idx >= 0) updateFileStatus(idx, 'success')
      })
      result.failFiles.forEach(ff => {
        const idx = batchFiles.findIndex(f => f.name === ff.name)
        if (idx >= 0) updateFileStatus(idx, 'fail', ff.error)
      })

      // Show success
      if (result.successCount > 0) {
        showSuccess(statusEl, `✅ 批量处理完成，${result.successCount} 成功 / ${result.failCount} 失败，耗时 ${(duration / 1000).toFixed(1)} 秒`)

        // Post-pipeline: prompt to save as template
        promptSaveTemplate(steps)

        // Show batch result summary
        let summaryHtml = `
          <div class="batch-result-row">
            <span class="label">📁 总文件数</span>
            <span class="value">${totalFiles}</span>
          </div>
          <div class="batch-result-row">
            <span class="label">✅ 成功</span>
            <span class="value success">${result.successCount}</span>
          </div>
          <div class="batch-result-row">
            <span class="label">❌ 失败</span>
            <span class="value fail">${result.failCount}</span>
          </div>
          <div class="batch-result-row">
            <span class="label">📏 总输入大小</span>
            <span class="value">${formatSize(totalOriginalSize)}</span>
          </div>
          <div class="batch-result-row">
            <span class="label">📦 ZIP 大小</span>
            <span class="value">${formatSize(result.zipBlob.size)}</span>
          </div>
        `

        if (result.failFiles.length > 0) {
          summaryHtml += '<div class="batch-result-divider"></div>'
          summaryHtml += '<div class="batch-fail-details"><strong>失败详情：</strong>'
          result.failFiles.forEach(ff => {
            summaryHtml += `<div class="batch-fail-item">❌ ${escapeHtml(ff.name)}: ${escapeHtml(ff.error)}</div>`
          })
          summaryHtml += '</div>'
        }

        batchSummary.innerHTML = summaryHtml
        batchResult.style.display = 'block'

        trackEvent('batch_pipeline_completed', {
          totalFiles,
          successCount: result.successCount,
          failCount: result.failCount,
          totalOriginalSize,
          zipSize: result.zipBlob.size,
          duration,
        })
      } else {
        showError(statusEl, '❌ 所有文件处理失败，请检查文件格式')
      }
    } catch (err) {
      console.error('[BatchPipeline] 执行失败:', err)
      showError(statusEl, '❌ 批量处理失败：' + err.message)
    } finally {
      runBtn.disabled = false
    }
  }

  function updateFileStatus(index, status, errorMsg) {
    const items = batchList.querySelectorAll('.batch-file-item')
    if (items[index]) {
      const statusEl2 = items[index].querySelector('.batch-file-status')
      if (status === 'processing') {
        statusEl2.textContent = '⏳'
        statusEl2.className = 'batch-file-status'
      } else if (status === 'success') {
        statusEl2.textContent = '✅'
        statusEl2.className = 'batch-file-status success'
      } else if (status === 'fail') {
        statusEl2.textContent = '❌'
        statusEl2.className = 'batch-file-status fail'
        statusEl2.title = errorMsg || ''
      }
    }
  }

  // =========================================================================
  // Download
  // =========================================================================

  // Single file download
  if (downloadBtn) {
    downloadBtn.addEventListener('click', () => {
      if (!resultBytes || !uploadedFile) return
      const baseName = uploadedFile.name.replace(/\.pdf$/i, '')
      const filename = baseName + '_workflow.pdf'
      downloadBlob(new Blob([resultBytes], { type: 'application/pdf' }), filename, true)
      cleanupResources()
    })
  }

  // Batch ZIP download
  if (batchDownloadBtn) {
    batchDownloadBtn.addEventListener('click', () => {
      if (!batchZipBlob) return
      downloadBlob(batchZipBlob, 'pdf_toolbox_batch.zip', true)
      cleanupResources()
    })
  }

  // Listen for step checkbox changes to update run button state
  document.querySelectorAll('.pipeline-step-check').forEach(cb => {
    cb.addEventListener('change', () => {
      updateWmOptionsVisibility()
      updateMdOptionsVisibility()
      updateMergeOptionsVisibility()
      updateSplitOptionsVisibility()
      updateBatchRunState()
    })
  })

  // =========================================================================
  // Safe Mode Auto-Check Strip JS
  // =========================================================================
  const stripJSCheck = document.querySelector('.pipeline-step-check[data-step="stripJS"]')

  /**
   * Auto-check stripJS when safe mode is active
   */
  function applySafeModeAutoCheck() {
    if (window.__safeMode && stripJSCheck) {
      stripJSCheck.checked = true
      updateWmOptionsVisibility()
    }
  }

  // Apply on init
  applySafeModeAutoCheck()

  // Listen for safe mode toggle changes
  const safeModeSwitch = document.getElementById('safe-mode-switch')
  if (safeModeSwitch) {
    safeModeSwitch.addEventListener('change', () => {
      applySafeModeAutoCheck()
    })
  }

  // =========================================================================
  // Close
  // =========================================================================
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      // Reset upload zone
      resetUploadZone(uploadZone)
      if (typeof window.closeModal === 'function') {
        window.closeModal('pipeline')
      }
    })
  }
}

/**
 * HTML escape helper
 */
function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}


