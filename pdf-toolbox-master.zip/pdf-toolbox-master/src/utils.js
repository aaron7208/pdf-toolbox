/**
 * utils.js - 共享工具函数
 */

// 统一文件大小上限(50MB)
export const MAX_FILE_SIZE = 50 * 1024 * 1024

/**
 * 骨架屏进度文案定时器管理
 * 每个调用 showProcessing 的元素关联一个定时器 ID
 */
const _skeletonTimers = new WeakMap()

/**
 * 数据监测:自定义事件追踪
 * 同时发送到 Microsoft Clarity 和 Google Analytics 4
 *
 * @param {string} eventName - 事件名称(如 'function_used', 'file_uploaded', 'file_downloaded')
 * @param {Object} params - 事件参数(如 { function: 'merge', size: 102400 })
 */
export function trackEvent(eventName, params = {}) {
  // --- Microsoft Clarity 自定义标签 ---
  if (typeof window.clarity === 'function') {
    try {
      const label = Object.keys(params).length > 0
        ? `${eventName}: ${JSON.stringify(params)}`
        : eventName
      window.clarity('set', eventName, JSON.stringify(params))
    } catch (e) {
      // Clarity 未加载或调用失败,静默忽略
    }
  }

  // --- Google Analytics 4 自定义事件 ---
  if (typeof window.gtag === 'function') {
    try {
      window.gtag('event', eventName, params)
    } catch (e) {
      // GA 未加载或调用失败,静默忽略
    }
  }

  // --- 开发环境:console 输出(方便调试) ---
  if (import.meta.env?.DEV || window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    console.log(`[trackEvent] ${eventName}`, params)
  }
}

// PDF.js worker CDN 配置
export const PDFJS_WORKER_VERSION = '3.11.174'
export const PDFJS_CDN_PRIMARY = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${PDFJS_WORKER_VERSION}/pdf.worker.min.js`
export const PDFJS_CDN_FALLBACK = `https://cdn.jsdelivr.net/npm/pdfjs-dist@${PDFJS_WORKER_VERSION}/build/pdf.worker.min.js`

/**
 * 检查文件大小,超出返回 false 并显示警告
 */
export function checkFileSize(file, statusEl) {
  if (file.size > MAX_FILE_SIZE) {
    showStatus(statusEl, `⚠️ 文件过大(${formatSize(file.size)}),建议不超过 50MB`, 'warning')
    return false
  }
  return true
}

/**
 * 格式化文件大小
 */
export function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

/**
 * 显示状态消息（自动添加图标）
 */
export function showStatus(el, message, type = 'info') {
  // 清除骨架屏定时器
  const timers = _skeletonTimers.get(el)
  if (timers) {
    clearTimeout(timers.timer1)
    clearTimeout(timers.timer2)
    _skeletonTimers.delete(el)
  }
  let icon = ''
  if (type === 'success' && !message.includes('✅')) {
    icon = '<span class="checkmark"></span>'
  } else if (type === 'error' && !message.includes('❌')) {
    icon = '<span class="error-icon"></span>'
  } else if (type === 'loading' && !message.includes('<span class="spinner"')) {
    icon = '<span class="spinner"></span>'
  }
  el.innerHTML = `<div class="status ${type}">${icon}${message}</div>`
}

/**
 * 显示处理状态(带安全锁动画 + 骨架屏动画 + 进度文案)
 * 用于文件处理过程中,显示"本地处理"标识,让用户感知文件不会上传
 * @param {HTMLElement} el - 状态容器
 * @param {string} message - 进度文字
 * @param {number} percent - 进度百分比 (0-100,可选)
 */
export function showProcessing(el, message, percent) {
  // 清除之前的定时器(避免多个 showProcessing 调用互相干扰)
  const prevTimer = _skeletonTimers.get(el)
  if (prevTimer) clearTimeout(prevTimer)

  const progressBar = percent != null
    ? `<div class="progress-bar-container"><div class="progress-bar" style="width:${percent}%"></div></div>`
    : ''

  el.innerHTML = `
    <div class="status processing has-skeleton">
      <span class="lock-icon"></span>${message}
      <span class="local-tip">🔒 文件正在本地处理,不会上传到任何服务器</span>
      <div class="skeleton-bars">
        <div class="skeleton-bar"></div>
        <div class="skeleton-bar"></div>
        <div class="skeleton-bar"></div>
      </div>
      <div class="progress-text" data-step="0">⏳ 正在解析文件...</div>
      ${progressBar}
    </div>`

  // 进度文案分 3 阶段切换:0.5s → "正在处理...",1.2s → "处理完成!"
  const progressTextEl = el.querySelector('.progress-text')
  let step = 0
  const timer1 = setTimeout(() => {
    if (!progressTextEl.isConnected) return
    progressTextEl.textContent = '⚙️ 正在处理...'
    progressTextEl.dataset.step = '1'
    step = 1
  }, 500)

  const timer2 = setTimeout(() => {
    if (!progressTextEl.isConnected) return
    progressTextEl.textContent = '✅ 处理完成!'
    progressTextEl.dataset.step = '2'
    step = 2
  }, 1200)

  _skeletonTimers.set(el, { timer1, timer2 })
}

/**
 * 显示进度条(保留原函数兼容性)
 * @param {HTMLElement} el - 状态容器
 * @param {string} message - 进度文字
 * @param {number} percent - 进度百分比 (0-100)
 */
export function showProgress(el, message, percent = 0) {
  el.innerHTML = `
    <div class="status loading">
      <span class="spinner"></span>${message}
      <div class="progress-bar-container">
        <div class="progress-bar" style="width:${percent}%"></div>
      </div>
      <div class="skeleton-bars">
        <div class="skeleton-bar"></div>
        <div class="skeleton-bar"></div>
        <div class="skeleton-bar"></div>
      </div>
    </div>`
}

/**
 * 显示成功状态(带动画)
 */
export function showSuccess(el, message) {
  // 清除骨架屏定时器
  const timers = _skeletonTimers.get(el)
  if (timers) {
    clearTimeout(timers.timer1)
    clearTimeout(timers.timer2)
    _skeletonTimers.delete(el)
  }
  el.innerHTML = `<div class="status success"><span class="checkmark"></span>${message}</div>`
}

// 功能列表（用于推荐引导）
const ALL_FEATURES = [
  { key: 'merge', label: '合并 PDF', icon: '📎' },
  { key: 'compress', label: '压缩 PDF', icon: '📦' },
  { key: 'split', label: '拆分 PDF', icon: '✂️' },
  { key: 'img', label: 'PDF 转图片', icon: '🖼️' },
  { key: 'watermark', label: '加水印', icon: '💧' },
  { key: 'img2pdf', label: '图片转 PDF', icon: '📸' },
  { key: 'invoice-nup', label: '发票拼版', icon: '🧾' },
]

/**
 * 显示处理报告卡片(带淡入动画)
 * 在 showSuccess 之后调用,追加报告卡片到状态元素
 * @param {HTMLElement} el - 状态容器
 * @param {Object} data - 报告数据
 * @param {string} data.fileName - 文件名
 * @param {number} data.originalSize - 原始大小(字节)
 * @param {number} [data.processedSize] - 处理后大小(字节,可选)
 * @param {number} [data.pageCount] - 页数
 * @param {number} [data.duration] - 处理耗时(毫秒)
 * @param {number} [data.fileCount] - 文件数量(如合并/拆分的结果数)
 * @param {string} [data.format] - 输出格式(如 png/jpg)
 * @param {string} [data.currentFeature] - 当前功能 key(可选,用于推荐引导)
 */
export function showReport(el, data) {
  const statusDiv = el.querySelector('.status.success')
  if (!statusDiv) return

  let html = '<div class="report-card">'
  html += '<div class="report-title">📋 处理报告</div>'

  // 文件名
  if (data.fileName) {
    html += `<div class="report-row"><span class="report-label">📄 文件名</span><span class="report-value">${escapeHtml(data.fileName)}</span></div>`
  }

  // 文件大小
  if (data.originalSize != null) {
    if (data.processedSize != null && data.processedSize !== data.originalSize) {
      const diff = data.processedSize - data.originalSize
      const pct = Math.abs((diff / data.originalSize) * 100).toFixed(1)
      const direction = diff < 0 ? '减少' : '增加'
      html += `<div class="report-row"><span class="report-label">📏 大小</span><span class="report-value">${formatSize(data.originalSize)} → ${formatSize(data.processedSize)}（${direction} ${pct}%）</span></div>`
    } else {
      html += `<div class="report-row"><span class="report-label">📏 大小</span><span class="report-value">${formatSize(data.originalSize)}</span></div>`
    }
  }

  // 页数
  if (data.pageCount != null) {
    html += `<div class="report-row"><span class="report-label">📊 页数</span><span class="report-value">${data.pageCount} 页</span></div>`
  }

  // 文件数量（合并/拆分等）
  if (data.fileCount != null && data.fileCount > 1) {
    html += `<div class="report-row"><span class="report-label">📁 文件</span><span class="report-value">${data.fileCount} 个</span></div>`
  }

  // 输出格式
  if (data.format) {
    html += `<div class="report-row"><span class="report-label">🎨 格式</span><span class="report-value">${data.format.toUpperCase()}</span></div>`
  }

  html += '<div class="report-divider"></div>'

  // 处理耗时
  if (data.duration != null) {
    const durationSec = (data.duration / 1000).toFixed(1)
    html += `<div class="report-row"><span class="report-label">⏱️ 耗时</span><span class="report-value highlight">${durationSec} 秒</span></div>`
  }

  // 本地处理
  html += `<div class="report-row"><span class="report-label">🔒 处理</span><span class="report-value">100% 本地处理，未上传任何数据</span></div>`

  html += '</div>'

  // 追加报告卡片到 status.success 内部
  statusDiv.insertAdjacentHTML('beforeend', html)

  // 操作后引导：推荐其他功能
  appendNextSteps(statusDiv, data.currentFeature, el)
}

/**
 * 追加"接下来你可以试试"推荐区域
 * @param {HTMLElement} statusDiv - 成功状态容器
 * @param {string|null} currentFeature - 当前功能 key
 * @param {HTMLElement} el - 原始状态元素（用于定位 panel）
 */
function appendNextSteps(statusDiv, currentFeature, el) {
  // 推断当前功能：优先用传入的 key，否则从 DOM 推断
  let featureKey = currentFeature
  if (!featureKey) {
    const panel = el.closest('[id^="panel-"]')
    if (panel) {
      featureKey = panel.id.replace('panel-', '')
    }
  }

  // 过滤掉当前功能，取前 3 个推荐
  const recommendations = ALL_FEATURES
    .filter(f => f.key !== featureKey)
    .slice(0, 3)

  if (recommendations.length === 0) return

  let html = '<div class="next-steps">'
  html += '<div class="next-steps-title">✨ 接下来你可以试试</div>'
  html += '<div class="next-steps-list">'

  recommendations.forEach(f => {
    html += `<a class="next-steps-item" data-next-modal="${f.key}" href="javascript:void(0)">`
    html += `<span class="next-steps-icon">${f.icon}</span>`
    html += `<span class="next-steps-label">${f.label}</span>`
    html += '</a>'
  })

  html += '</div></div>'

  statusDiv.insertAdjacentHTML('beforeend', html)

  // 绑定点击事件：关闭当前 modal → 打开推荐 modal
  const panel = el.closest('[id^="panel-"]')
  const currentModalKey = panel ? panel.id.replace('panel-', '') : featureKey

  statusDiv.querySelectorAll('.next-steps-item').forEach(item => {
    item.addEventListener('click', () => {
      const targetKey = item.dataset.nextModal
      if (typeof window.closeModal === 'function' && typeof window.openModal === 'function') {
        window.closeModal(currentModalKey)
        window.openModal(targetKey)
      }
    })
  })
}

/**
 * HTML 转义
 */
function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

/**
 * 显示错误状态(带动画)
 */
export function showError(el, message) {
  // 清除骨架屏定时器
  const timers = _skeletonTimers.get(el)
  if (timers) {
    clearTimeout(timers.timer1)
    clearTimeout(timers.timer2)
    _skeletonTimers.delete(el)
  }
  el.innerHTML = `<div class="status error"><span class="error-icon"></span>${message}</div>`
}

/**
 * 清除状态消息
 */
export function clearStatus(el) {
  // 清除骨架屏进度文案定时器
  const timers = _skeletonTimers.get(el)
  if (timers) {
    clearTimeout(timers.timer1)
    clearTimeout(timers.timer2)
    _skeletonTimers.delete(el)
  }
  el.innerHTML = ''
}

/**
 * 下载 Blob 文件
 * @param {Blob} blob - 要下载的 Blob
 * @param {string} filename - 文件名
 * @param {boolean} count - 是否计入隐私计数器(默认 false)
 */
export function downloadBlob(blob, filename, count = false) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  setTimeout(() => URL.revokeObjectURL(url), 1000)

  // 更新隐私计数器(用户成功下载处理后的文件)
  if (count) {
    try {
      const STORAGE_KEY = 'pdf-toolbox-processed-count'
      const current = parseInt(localStorage.getItem(STORAGE_KEY) || '0', 10) || 0
      const newCount = current + 1
      localStorage.setItem(STORAGE_KEY, newCount.toString())
      // 更新 Hero 区显示(如果元素存在)
      const el = document.getElementById('privacy-counter-value')
      if (el) {
        animateCounter(el, newCount)
      }
    } catch (e) {
      // localStorage 不可用时静默忽略
    }
  }
}

/**
 * 数字滚动动画
 */
function animateCounter(el, targetValue) {
  const duration = 800
  const startTime = performance.now()
  const startValue = parseInt(el.dataset.current || '0', 10) || 0

  function step(currentTime) {
    const elapsed = currentTime - startTime
    const progress = Math.min(elapsed / duration, 1)
    const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress)
    const currentValue = Math.round(startValue + (targetValue - startValue) * eased)
    el.textContent = currentValue.toLocaleString('en-US')
    el.dataset.current = currentValue.toString()
    if (progress < 1) {
      requestAnimationFrame(step)
    }
  }
  requestAnimationFrame(step)
}

/**
 * 计算响应式缩放比例
 */
export function computeResponsiveScale(page, containerWidth, containerHeight, padding = 32) {
  const { width: pageWidth, height: pageHeight } = page.getViewport({ scale: 1 })
  const availableWidth = containerWidth - padding
  const availableHeight = containerHeight - padding
  const scaleX = availableWidth / pageWidth
  const scaleY = availableHeight / pageHeight
  return Math.max(Math.min(scaleX, scaleY), 0.25)
}

/**
 * 渲染 PDF 页面到 Canvas(固定缩放比例)
 */
export async function renderPage(pdfDoc, pageNum, canvas, scale = 1.5) {
  const page = await pdfDoc.getPage(pageNum)
  const viewport = page.getViewport({ scale })
  canvas.width = viewport.width
  canvas.height = viewport.height
  canvas.style.width = ''
  canvas.style.height = ''
  const ctx = canvas.getContext('2d')
  await page.render({ canvasContext: ctx, viewport }).promise
}

/**
 * 渲染 PDF 页面到 Canvas(响应式,自动适配容器)
 */
export async function renderPageResponsive(pdfDoc, pageNum, canvas, container, baseScale = 1) {
  const page = await pdfDoc.getPage(pageNum)
  const containerWidth = container ? container.clientWidth : 800
  const containerHeight = container ? container.clientHeight : 600
  const scale = computeResponsiveScale(page, containerWidth, containerHeight) * baseScale
  const viewport = page.getViewport({ scale })
  canvas.width = Math.round(viewport.width)
  canvas.height = Math.round(viewport.height)
  canvas.style.width = viewport.width + 'px'
  canvas.style.height = viewport.height + 'px'
  const ctx = canvas.getContext('2d')
  await page.render({ canvasContext: ctx, viewport }).promise
  return scale
}

/**
 * 解析页码范围字符串
 * 支持格式: "1,3,5-8,10"
 */
export function parsePageRange(str, max) {
  const pages = new Set()
  const warnings = []
  const parts = str.split(',')
  for (const part of parts) {
    const trimmed = part.trim()
    if (!trimmed) continue
    if (trimmed.includes('-')) {
      const [a, b] = trimmed.split('-').map(Number)
      if (!isNaN(a) && !isNaN(b)) {
        if (a > b) {
          warnings.push(`页码范围 "${trimmed}" 无效(起始页 ${a} 大于结束页 ${b})`)
          continue
        }
        for (let i = Math.max(1, a); i <= Math.min(max, b); i++) pages.add(i)
      }
    } else {
      const n = Number(trimmed)
      if (!isNaN(n) && n >= 1 && n <= max) pages.add(n)
    }
  }
  return { pages: [...pages].sort((a, b) => a - b), warnings }
}

/**
 * 十六进制颜色转 RGB 0-1 范围
 */
export function hexToRgb01(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255
  const g = parseInt(hex.slice(3, 5), 16) / 255
  const b = parseInt(hex.slice(5, 7), 16) / 255
  return { r, g, b }
}

/**
 * 获取全局 PDF.js 实例（main.js 已初始化）
 * 延迟加载避免循环依赖
 */
async function getPdfjs() {
  if (window.pdfjsLib) return window.pdfjsLib
  try {
    const lib = await import('pdfjs-dist')
    window.pdfjsLib = lib
    return lib
  } catch {
    return null
  }
}

/**
 * 在上传区显示文件信息（文件名、大小、页数）
 * 替换原有的提示文字，高亮边框表示已接收
 *
 * @param {HTMLElement} uploadZone - 上传区 DOM 元素
 * @param {File} file - 文件对象
 * @param {string} [pdfId] - 可选，用于区分同一模块的多个上传区
 * @returns {Promise<number>} PDF 页数（非 PDF 返回 0）
 */
export async function showUploadFileInfo(uploadZone, file, pdfId) {
  const id = pdfId || file.name
  const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')
  const isImage = file.type.startsWith('image/') || /\.(jpe?g|png)$/i.test(file.name)

  // 获取页数（仅 PDF）
  let pageCount = 0
  if (isPdf) {
    try {
      const lib = await getPdfjs()
      if (lib) {
        const bytes = await file.arrayBuffer()
        const pdfDoc = await lib.getDocument({ data: new Uint8Array(bytes) }).promise
        pageCount = pdfDoc.numPages
      }
    } catch (e) {
      console.warn('[showUploadFileInfo] 获取页数失败:', e)
    }
  }

  // 渲染上传区内容
  renderFileInfo(uploadZone, file, pageCount, isPdf, isImage, id)

  return pageCount
}

/**
 * 渲染文件信息到上传区
 */
function renderFileInfo(uploadZone, file, pageCount, isPdf, isImage, id) {
  // 移除已有 info 元素（如果有）
  const existing = uploadZone.querySelector('.upload-file-info')
  if (existing) existing.remove()

  // 隐藏原有内容
  const iconEl = uploadZone.querySelector('.icon')
  const paragraphs = uploadZone.querySelectorAll('p')
  if (iconEl) iconEl.style.display = 'none'
  paragraphs.forEach(p => p.style.display = 'none')

  // 添加 has-file 类（高亮边框）
  uploadZone.classList.add('has-file')

  // 选择文件图标
  let fileIcon = '📄'
  if (isImage) fileIcon = '🖼️'

  // 构建信息 HTML
  const infoDiv = document.createElement('div')
  infoDiv.className = 'upload-file-info'
  infoDiv.dataset.fileId = id

  let infoHtml = `
    <div class="upload-file-header">
      <span class="upload-file-icon">${fileIcon}</span>
      <span class="upload-file-name" title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</span>
    </div>
    <div class="upload-file-details">
      <span class="upload-file-size">📊 ${formatSize(file.size)}</span>
  `

  if (isPdf && pageCount > 0) {
    infoHtml += `<span class="upload-file-pages">📑 ${pageCount} 页</span>`
  }

  infoHtml += `
    </div>
    <div class="upload-file-hint">点击或拖入替换文件</div>
  `

  infoDiv.innerHTML = infoHtml
  uploadZone.appendChild(infoDiv)
}

/**
 * 高亮上传区边框（多文件场景，不显示单文件信息）
 */
export function highlightUploadZone(uploadZone) {
  uploadZone.classList.add('has-file')
}

/**
 * 重置上传区到初始状态
 */
export function resetUploadZone(uploadZone) {
  uploadZone.classList.remove('has-file')
  const info = uploadZone.querySelector('.upload-file-info')
  if (info) info.remove()

  // 恢复原有内容
  const iconEl = uploadZone.querySelector('.icon')
  const paragraphs = uploadZone.querySelectorAll('p')
  if (iconEl) iconEl.style.display = ''
  paragraphs.forEach(p => p.style.display = '')
}

/**
 * 强制释放内存资源
 * 在每次处理完成后调用，清除 Blob URL 和 Canvas 对象引用，防止内存泄漏
 */
export function cleanupResources() {
  // 1. 清理所有悬空的 Blob URL（延迟执行，确保下载已开始）
  setTimeout(() => {
    try {
      document.querySelectorAll('a[href^="blob:"], img[src^="blob:"]').forEach(el => {
        try {
          URL.revokeObjectURL(el.href || el.src)
          if (el.href) el.removeAttribute('href')
          if (el.src) el.removeAttribute('src')
        } catch (_) { /* ignore */ }
      })
    } catch (_) { /* ignore */ }
  }, 2000)

  // 2. 清理所有 Canvas 上下文引用
  try {
    document.querySelectorAll('canvas').forEach(canvas => {
      try {
        const ctx = canvas.getContext('2d')
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height)
        }
        canvas.width = 0
        canvas.height = 0
      } catch (_) { /* ignore */ }
    })
  } catch (_) { /* ignore */ }
}
