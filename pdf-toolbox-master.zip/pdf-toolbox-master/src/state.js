/**
 * state.js - 全局状态管理
 */

export const state = {
  // View module state
  view: {
    pdfDoc: null,
    pdfBytes: null,
    currentPage: 1,
    totalPages: 0,
    scale: 1.5
  },

  // Merge module state
  merge: {
    files: []
  },

  // Compress module state
  compress: {
    pdfFile: null,
    pdfBytes: null,
    totalPages: 0
  },

  // Img module state (PDF to image)
  img: {
    pdfDoc: null,
    file: null,
    totalPages: 0
  },

  // Split module state
  split: {
    pdfDoc: null,
    pdfBytes: null,
    file: null,
    totalPages: 0
  },

  // Img2Pdf module state (images to PDF)
  img2pdf: {
    files: [],
    pdfDoc: null
  },

  // Watermark module state
  watermark: {
    pdfDoc: null,
    pdfBytes: null,
    file: null,
    totalPages: 0
  },

  // Invoice N-up module state
  invoiceNup: {
    files: []
  },

  // Redaction module state
  redaction: {
    pdfDoc: null,
    pdfBytes: null,
    file: null,
    totalPages: 0
  }
}
